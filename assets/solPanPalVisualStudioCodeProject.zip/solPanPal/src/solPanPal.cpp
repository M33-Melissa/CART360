/******************************************************/
//       THIS IS A GENERATED FILE - DO NOT EDIT       //
/******************************************************/

#include "Particle.h"
#line 1 "c:/Users/solpa/Documents/Particle/solPanPal/src/solPanPal.ino"
// #include "pitches.h" // include pitches library
void setup();
void loop();
void sendData(float accData[3], float gyrData[3], float magData[3]);
void panPalLoop();
void readStroke();
void checkState(float lPet, float rPet);
void resetO();
void purr();
void wakeEyes();
void sleepEyes(int maxi);
#line 2 "c:/Users/solpa/Documents/Particle/solPanPal/src/solPanPal.ino"
#define PI 3.1415926535897932384626433832795

// const int PIEZO_PIN = D2;

// constants for RGB LED
const int LED_PIN_R = A3; // B PIN
const int LED_PIN_G = A4; // G PIN
const int LED_PIN_B = A5; // R PIN

const int STROKE_L = A0; // stroke sensor
const int STROKE_R = A1;

const int VIBRA = D3; // vibration motor

float gyrAvg;

// //

// #define PIEZO_PIN 6

// // constants for RGB LED
// #define LED_PIN_R 4   // B PIN
// #define LED_PIN_G 3  // G PIN
// #define LED_PIN_B 2   // R PIN

// #define STROKE_R A3 // stroke sensor
// #define STROKE_L A4

// #define VIBRA A5 // vibration motor

//

int b = 0;
int g = 0;
int r = 0;

// const int MAX_NOTES = 16;
// int notes[MAX_NOTES];
// int currentNote = 0;

/*****************************************************************/

// Includes
#include "SEN10724.h"

// Object instantiation
SEN10724 sen10724;

// Time
unsigned long timestamp;
unsigned long timestamp_old;
float deltaT;

void setup()
{
  Serial.begin(57600);

  /*****************************************************************/
  pinMode(STROKE_L, INPUT);
  pinMode(STROKE_R, INPUT);
  pinMode(VIBRA, OUTPUT);
  pinMode(LED_PIN_B, OUTPUT);
  pinMode(LED_PIN_G, OUTPUT);
  pinMode(LED_PIN_R, OUTPUT);
  // while (!Serial);

  /*****************************************************************/

  Serial.println("Initialize SEN 10724 Sensor Stick");
  if (!sen10724.begin())
  {
    Serial.println("Error");
    delay(500);
  }

  // Calibration values for accelerometer
  float accMaxValues[3] = {1.064, 1.016, 1.044};
  float accMinValues[3] = {-1.068, -1.08, -1.236};

  // Calibration values for gyroscope
  float gyrOffsets[3] = {-0.904, 5.426, 0.626};

  // Calbration values for magnetometer
  float magEllipsoidCenter[3] = {-178.266, 92.8594, -59.4538};
  float magEllipsoidTransform[3][3] = {{0.789315, -0.0151758, -0.0645366},
                                       {-0.0151758, 0.982619, 0.00424189},
                                       {-0.0645366, 0.00424189, 0.975379}};

  // Set the calibration values
  sen10724.setAccMaxMinValues(accMaxValues, accMinValues);
  sen10724.setGyrOffsets(gyrOffsets);
  sen10724.setMagEllipsoidCalib(magEllipsoidCenter, magEllipsoidTransform);

  // Accelerometer configuration
  sen10724.setAccRange(ADXL345_RANGE_16G);
  sen10724.setAccDataRate(ADXL345_DATARATE_400HZ);

  // Gyroscope configuration
  sen10724.setGyrFs(ITG3200_FS_2000);
  sen10724.setGyrLowPass(ITG3200_LOWPASS_42);
  sen10724.setGyrClk(ITG3200_CLK_INTERNAL);
  sen10724.setGyrRateDivider(9);

  // Magnetometer configuration
  sen10724.setMagRange(HMC5883L_RANGE_1_3GA);
  sen10724.setMagMeasurementMode(HMC5883L_CONTINOUS);
  sen10724.setMagDataRate(HMC5883L_DATARATE_15HZ);
  sen10724.setMagSamples(HMC5883L_SAMPLES_1);

  delay(50);
  Serial.println("SEN 10724 was initiated successfully");
}

void loop()
{
  // Calcualte time since last update
  timestamp_old = timestamp;
  timestamp = micros();
  if (timestamp > timestamp_old)
    deltaT = (float)(timestamp - timestamp_old) / 1000000.0f;
  else
    deltaT = 0;

  // Read values
  float *accCalib = sen10724.readAccCalib();
  float *gyrCalib = sen10724.readGyrCalib();
  float *magCalib = sen10724.readMagCalib();

  // Print values to serial port
  sendData(accCalib, gyrCalib, magCalib);

  /*****************************************************************/
  panPalLoop();
  /*****************************************************************/
}

void sendData(float accData[3], float gyrData[3], float magData[3])
{
  // Serial.print("Time-Acc-Gyr-Mag=");
  // Serial.print(String(deltaT, 5));
  // Serial.print("x: ");
  // Serial.print(String(accData[0], 2));
  // Serial.print("y: ");
  // Serial.print(String(accData[1], 2));
  // Serial.print("z: ");
  // Serial.print(String(accData[2], 2));
  // Serial.print(",");
  // Serial.print(String(gyrData[0], 3));
  // Serial.print(",");
  // Serial.print(String(gyrData[1], 3));
  // Serial.print(",");
  // Serial.print(String(gyrData[2], 3));
  // Serial.print(",");
  // Serial.print(String(magData[0], 3));
  // Serial.print(",");
  // Serial.print(String(magData[1], 3));
  // Serial.print(",");
  // Serial.println(String(magData[2], 3));

  gyrAvg = (abs(gyrData[0]) + abs(gyrData[1]) + abs(gyrData[2])) / 3;
  Serial.print(" gyr: ");
  Serial.println(gyrAvg);
}

/*****************************************************************/

void panPalLoop()
{
  readStroke();
  delay(50);
}

void readStroke()
{
  float lPet = analogRead(STROKE_L);
  float rPet = analogRead(STROKE_R);

  Serial.print("left: ");
  Serial.print(lPet);
  Serial.print(" right: ");
  Serial.print(rPet);

  checkState(lPet, rPet);
  delay(500);
}

void checkState(float lPet, float rPet)
{
  if (gyrAvg > 20)
  {
    wakeEyes();
    delay(1000);
  }
  else if (lPet >= 4000 || rPet >= 4000)
  {
    purr();
    delay(1000);
  }
  else
  {
    delay(500);
    resetO();
  }
}

void resetO()
{
  analogWrite(VIBRA, 0);
  analogWrite(LED_PIN_R, 0);
  analogWrite(LED_PIN_G, 0);
  analogWrite(LED_PIN_B, 0);
}

void purr()
{
  int silence = random(50, 55);
  int modif = random(-50, 0);
  int purVal = 100 + silence + modif;

  analogWrite(VIBRA, random(purVal / 4, purVal));
  delay(silence);
  Serial.print(" purr: ");
  Serial.print(purVal);
}

void wakeEyes()
{

  int maxi = random(155, 255);
  if (g < maxi)
  {
    g++;
    analogWrite(LED_PIN_R, random(50,100));
    analogWrite(LED_PIN_G, g);
    analogWrite(LED_PIN_B, g);
    delay(sin(g));
  }
  if (g == maxi)
  {
    g=0;
    delay(500);
    sleepEyes(maxi);
  }
}

void sleepEyes(int maxi)
{
  if (b == 0)
  {
    b = maxi;
  }
  if (b > 0 && b <= maxi)
  {
    b--;
    delay(tan(b));
    analogWrite(LED_PIN_R, random(50,100));
    analogWrite(LED_PIN_G, b);
    analogWrite(LED_PIN_B, b);
  }
}